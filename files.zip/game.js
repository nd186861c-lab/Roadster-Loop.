(()=>{'use strict';
// World units = feet. Gravity & speeds are scaled by 0.5 so the 26 u/s^2 thrusters can beat gravity (16.1).
const G=16.1,MPH=.7333,DT=1/120,R1=22,WH=14,R2=9,SW=22*Math.PI/180,FL=90,L1=R1*Math.PI/2,TOT=FL+L1+WH+R2*SW,CO=1.4,PI=Math.PI,TAU=PI*2;
const $=i=>document.getElementById(i),cl=(v,a,b)=>Math.max(a,Math.min(b,v)),wrap=a=>{a%=TAU;return a>PI?a-TAU:a<-PI?a+TAU:a};
let ac;function beep(f,d,t,v){try{ac=ac||new AudioContext();const o=ac.createOscillator(),g=ac.createGain();o.type=t||'square';o.frequency.value=f;g.gain.value=v||.06;o.connect(g);g.connect(ac.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,ac.currentTime+d);o.stop(ac.currentTime+d)}catch(e){}}
// ramp path sampled by arc length s -> [x,y,heading]
function path(s){let a;if(s<FL)return[s-FL,0,0];
if(s<FL+L1){a=(s-FL)/R1;return[R1*Math.sin(a),R1*(1-Math.cos(a)),a]}
if(s<FL+L1+WH)return[R1,R1+s-FL-L1,PI/2];
a=(s-FL-L1-WH)/R2;return[R1-R2+R2*Math.cos(a),R1+WH+R2*Math.sin(a),PI/2+a]}
// ---- scene
const ren=new THREE.WebGLRenderer({canvas:$('c'),antialias:true}),scene=new THREE.Scene(),cam=new THREE.PerspectiveCamera(50,1,1,2500);
ren.setPixelRatio(Math.min(devicePixelRatio,2));scene.background=new THREE.Color(0x050816);scene.fog=new THREE.FogExp2(0x050816,.0035);
function rsz(){ren.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()}addEventListener('resize',rsz);rsz();
scene.add(new THREE.HemisphereLight(0x7088ff,0x101020,.9));const moon=new THREE.DirectionalLight(0xaabbff,.8);moon.position.set(-40,80,60);scene.add(moon);
const M=(c,o)=>new THREE.MeshStandardMaterial(Object.assign({color:c,roughness:.6,metalness:.2},o)),B=c=>new THREE.MeshBasicMaterial({color:c});
function plane(w,h,c,y){const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),M(c));m.rotation.x=-PI/2;m.position.set(-1000,y,0);scene.add(m)}
plane(4000,600,0x070a14,-.05);plane(4000,16,0x14161f,0);
{const dg=new THREE.BoxGeometry(10,.05,.5),dm=B(0xcfd8ff),pg=new THREE.BoxGeometry(.5,16,.5),pm=M(0x2a2f45),hg=new THREE.BoxGeometry(2,.4,1),hm=B(0xffe9a8);
for(let i=0;i<80;i++){const d=new THREE.Mesh(dg,dm);d.position.set(20-i*22,.03,0);scene.add(d)}
for(let i=0;i<30;i++)for(const z of[-12,12]){const p=new THREE.Mesh(pg,pm),h=new THREE.Mesh(hg,hm);p.position.set(40-i*50,8,z);h.position.set(40-i*50,16,z);scene.add(p,h)}}
const sp=new Float32Array(1500);for(let i=0;i<500;i++){sp[i*3]=(Math.random()-.5)*1200;sp[i*3+1]=30+Math.random()*400;sp[i*3+2]=-250-Math.random()*200}
const stars=new THREE.Points(new THREE.BufferGeometry().setAttribute('position',new THREE.BufferAttribute(sp,3)),new THREE.PointsMaterial({color:0xffffff,size:1.6,fog:false}));scene.add(stars);
{const sf=[],ot=[];for(let s=FL-6;s<=TOT+.01;s+=.5){const[px,py,h]=path(Math.min(s,TOT));sf.push(new THREE.Vector2(px,py));ot.push(new THREE.Vector2(px+Math.sin(h)*3,py-Math.cos(h)*3))}
const g=new THREE.ExtrudeGeometry(new THREE.Shape(sf.concat(ot.reverse())),{depth:16,bevelEnabled:false});g.translate(0,0,-8);
scene.add(new THREE.Mesh(g,M(0x1d2233,{metalness:.5,side:THREE.DoubleSide})));
for(const z of[-8.05,8.05])scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(sf.map(p=>new THREE.Vector3(p.x,p.y,z))),new THREE.LineBasicMaterial({color:0x35e0ff})))}
// ---- original car
const car=new THREE.Group(),wh=[],pl=[];
{const bm=M(0xdfe6f2,{metalness:.8,roughness:.2}),gm=M(0x07101c,{metalness:.9,roughness:.1}),sph=new THREE.SphereGeometry(1,24,12);
let m=new THREE.Mesh(sph,bm);m.scale.set(7.5,1.2,3);car.add(m);
m=new THREE.Mesh(sph,gm);m.scale.set(3.4,1,2.3);m.position.set(-.8,.9,0);car.add(m);
m=new THREE.Mesh(new THREE.BoxGeometry(.25,.18,4.4),B(0xaef0ff));m.position.set(7.2,.2,0);car.add(m);
m=new THREE.Mesh(new THREE.BoxGeometry(.25,.18,4.4),B(0xff2244));m.position.set(-7.2,.3,0);car.add(m);
const wg=new THREE.CylinderGeometry(1.1,1.1,.9,16).rotateX(PI/2),cg=new THREE.ConeGeometry(.55,4.5,12).rotateX(PI).translate(0,-2.4,0);
for(const sx of[-1,1])for(const sz of[-1,1]){m=new THREE.Mesh(wg,M(0x111111));m.position.set(sx*4.6,-.3,sz*2.9);car.add(m);wh.push(m);
const c=new THREE.Mesh(cg,new THREE.MeshBasicMaterial({color:0x5ab4ff,transparent:true,opacity:.75}));c.position.set(sx*4.4,-1.1,sz*1.6);c.visible=false;car.add(c);pl.push(c)}
const hl=new THREE.PointLight(0x66ccff,1.2,70);hl.position.set(10,2,0);car.add(hl)}
scene.add(car);const flash=new THREE.PointLight(0xffaa44,0,120);scene.add(flash);
// ---- state
let st='title',ct=0,ln=0,green=false,greenAt=3,lock=0,tmr=0,s=0,v=0,v0=0,acc=0,x=-FL,y=CO,vx=0,vy=0,th=0,om=0,gas=1,rings=0,flips=0,inv=false,airT=0,maxAlt=0,peakG=1,react=0,rampMph=0,sink=0,score=0,okL=false,shake=0,rs=[],db=[],best=0;const keys={};
try{best=+localStorage.getItem('roadsterLoopBest')||0}catch(e){}
const P=$('panel'),show=h=>{P.innerHTML=h;P.style.display=h?'flex':'none'},msg=t=>$('msg').textContent=t;
function title(){show('<h1>Roadster Loop</h1><p>Wait for the green light, launch, climb the wall and fly.<br>&larr;/&rarr; rotate &middot; Space (or tap) fires thrusters<br>Collect rings, land upright and soft (&le; 39 ft/s).</p><button>Start</button>')}
function startRun(){rs.forEach(r=>scene.remove(r.m));db.forEach(d=>scene.remove(d.m));rs=[];db=[];car.visible=true;flash.intensity=0;
st='count';ct=0;ln=0;green=false;lock=0;greenAt=2.8+Math.random()*1.6;s=v=om=th=0;x=-FL;y=CO;gas=1;rings=flips=0;inv=false;airT=maxAlt=0;peakG=1;shake=0;show('');msg('Wait for green…');if(document.activeElement)document.activeElement.blur()}
function launch(){react=ct-greenAt;rampMph=cl(90-5*react,76,90);v0=rampMph*MPH;acc=v0*v0/(2*FL);st='drive';msg('');beep(880,.2)}
function press(){if(st==='title'||st==='results')return startRun();if(st!=='count'||lock>0)return;
if(!green){lock=.4;beep(180,.3,'sawtooth');msg('Too early, wait for green');return}launch()}
function mkRings(){const T=(vy+Math.sqrt(vy*vy+2*G*y))/G;for(const f of[.12,.28,.44,.6,.76,.9]){const t=T*f,m=new THREE.Mesh(new THREE.TorusGeometry(5,.35,8,28),B(0xffd24a));m.position.set(x+vx*t,y+vy*t-.5*G*t*t,0);scene.add(m);rs.push({m,x:m.position.x,y:m.position.y,got:false})}}
function calc(bonus){score=rings*500+flips*1500+Math.round(maxAlt)*5+Math.round(airT*100)+bonus}
function touch(){sink=-vy;const tilt=Math.abs(wrap(th))*180/PI;okL=sink<=39&&tilt<=28;tmr=0;
if(okL){st='landed';y=CO;vy=0;th=wrap(th);calc(500+Math.round(500*(1-sink/39)));msg('Soft landing!');beep(300,.25,'sine',.1)}
else{st='crashed';car.visible=false;flash.position.set(x,y,0);flash.intensity=8;shake=2.2;calc(0);msg('CRASH!');beep(70,.7,'sawtooth',.15);
for(let i=0;i<36;i++){const m=new THREE.Mesh(new THREE.BoxGeometry(.4+Math.random(),.4+Math.random(),.4+Math.random()),B([0xdfe6f2,0xff8a2a,0x222233][i%3]));m.position.set(x,Math.max(y,1),0);scene.add(m);
const a=Math.random()*TAU,sp=8+Math.random()*30;db.push({m,vx:vx*.4+Math.cos(a)*sp,vy:Math.abs(Math.sin(a))*sp+10,vz:(Math.random()-.5)*30})}}}
function step(){
if(st==='count'){ct+=DT;lock=Math.max(0,lock-DT);const n=Math.min(4,Math.floor(ct/.5));if(n!==ln){ln=n;beep(440,.1)}
if(!green&&ct>=greenAt){green=true;msg('GO!');beep(1000,.35,'sine')}if(green&&ct-greenAt>3)launch()}
else if(st==='drive'||st==='ramp'){
if(s<FL)v=Math.min(v0,v+acc*DT);else v-=G*Math.sin(path(s)[2])*DT;
s+=v*DT;if(s>=FL)st='ramp';
const k=s>=FL+L1+WH?1/R2:s>=FL&&s<FL+L1?1/R1:0;peakG=Math.max(peakG,1+v*v*k/32.2);
const q=path(Math.min(s,TOT)),h=q[2];x=q[0]-Math.sin(h)*CO;y=q[1]+Math.cos(h)*CO;th=h;
if(s>=TOT){vx=v*Math.cos(h);vy=v*Math.sin(h);om=0;st='air';airT=0;mkRings();beep(660,.2)}}
else if(st==='air'){airT+=DT;
if(keys.space&&gas>0){vx-=Math.sin(th)*26*DT;vy+=Math.cos(th)*26*DT;gas=Math.max(0,gas-.28*DT)}
vy-=G*DT;om+=((keys.l?1:0)-(keys.r?1:0))*9*DT;om*=1-.5*DT;th+=om*DT;x+=vx*DT;y+=vy*DT;maxAlt=Math.max(maxAlt,y-CO);
const a=Math.abs(wrap(th));if(a>2.6){if(!inv){inv=true;flips++;beep(520,.1,'triangle')}}else if(a<1.7)inv=false;
for(const r of rs)if(!r.got&&Math.hypot(r.x-x,r.y-y)<6){r.got=true;r.m.visible=false;rings++;gas=Math.min(1,gas+.35);beep(1200,.15,'sine',.1)}
const sn=Math.sin(th),cs=Math.cos(th);let mn=1e9;for(const[a1,b1]of[[5,-CO],[-5,-CO],[3,1.2],[-3,1.2]])mn=Math.min(mn,y+sn*a1+cs*b1);
if(mn<=0)touch()}
else if(st==='landed'){tmr+=DT;vx*=1-2.2*DT;x+=vx*DT;th*=1-6*DT;if(tmr>1.8)results()}
else if(st==='crashed'){tmr+=DT;if(tmr>2)results()}}
function grade(){return!okL?'F':score>=7000?'S':score>=5000?'A':score>=3500?'B':score>=2000?'C':'D'}
function results(){st='results';msg('');const nb=okL&&score>best;if(nb){best=score;try{localStorage.setItem('roadsterLoopBest',best)}catch(e){}}
const r=(a,b)=>`<div><span>${a}</span><br><b>${b}</b></div>`;
show(`<h2>${okL?'Landed!':'Crashed'}</h2><div class="gr">${grade()}</div>${nb?'<span class="nb">NEW BEST</span>':''}<div class="big">${score}</div><div class="st">${r('Reaction',react.toFixed(3)+' s')}${r('Ramp speed',rampMph.toFixed(1)+' mph')}${r('Peak G',peakG.toFixed(1)+' G')}${r('Max altitude',Math.round(maxAlt)+' ft')}${r('Airtime',airT.toFixed(1)+' s')}${r('Flips',flips)}${r('Rings',rings+' / 6')}${r('Touchdown',sink.toFixed(1)+' ft/s')}</div><button>Run it again</button>`)}
// ---- render
const L=$('lights').children;
function render(dt){
car.position.set(x,y,0);car.rotation.z=th;
const spin=st==='drive'||st==='ramp'?v:st==='landed'?vx:0;wh.forEach(w=>w.rotation.z-=spin*dt/1.1);
const burn=st==='air'&&keys.space&&gas>0;pl.forEach(p=>{p.visible=burn;p.scale.set(1,.7+Math.random()*.6,1)});
$('lights').style.opacity=st==='count'||st==='drive'?1:0;
if(st==='count'){const n=Math.min(4,Math.floor(ct/.5));for(let i=0;i<4;i++)L[i].className=i<n?(green&&i===3?'g':'r'):''}
const alt=Math.max(0,y),d=cl(62+alt*.55,62,170),tx=x+(st==='air'?0:14),ty=Math.max(y,10)+alt*.1,k=Math.min(1,dt*4);
cam.position.x+=(tx-cam.position.x)*k;cam.position.y+=(ty+6-cam.position.y)*k;cam.position.z+=(d-cam.position.z)*Math.min(1,dt*2);
shake*=.92;cam.lookAt(cam.position.x+(Math.random()-.5)*shake*2,cam.position.y-6+(Math.random()-.5)*shake*2,0);stars.position.x=cam.position.x*.95;
flash.intensity*=.9;for(const o of db){o.vy-=30*dt;o.m.position.x+=o.vx*dt;o.m.position.y+=o.vy*dt;o.m.position.z+=o.vz*dt;o.m.rotation.x+=dt*5;if(o.m.position.y<.3){o.m.position.y=.3;o.vy*=-.3;o.vx*=.7;o.vz*=.7}}
$('sp').textContent=Math.round((st==='air'?Math.hypot(vx,vy):st==='landed'?vx:v)/MPH);$('al').textContent=Math.round(Math.max(0,y-CO));
$('gas').style.width=gas*100+'%';$('bs').textContent=best;
if(st==='air')calc(0);
$('sc').textContent=score;
ren.render(scene,cam)}
let last=0,acu=0;function loop(t){requestAnimationFrame(loop);const dt=Math.min(.1,(t-last)/1000||0);last=t;acu+=dt;while(acu>=DT){step();acu-=DT}render(dt)}
// ---- input
addEventListener('keydown',e=>{if(e.code==='Space'){e.preventDefault();if(!e.repeat)press();keys.space=true}if(e.code==='ArrowLeft'){e.preventDefault();keys.l=true}if(e.code==='ArrowRight'){e.preventDefault();keys.r=true}});
addEventListener('keyup',e=>{if(e.code==='Space')keys.space=false;if(e.code==='ArrowLeft')keys.l=false;if(e.code==='ArrowRight')keys.r=false});
$('c').addEventListener('pointerdown',()=>{press();keys.space=true});addEventListener('pointerup',()=>{keys.space=false;keys.l=keys.r=false});
for(const[id,k]of[['tl','l'],['tr','r']])$(id).addEventListener('pointerdown',e=>{e.stopPropagation();keys[k]=true});
P.addEventListener('click',e=>{if(e.target.tagName==='BUTTON')startRun()});
cam.position.set(-FL,16,62);title();requestAnimationFrame(loop);
})();
